"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { MessageSquare, Video, Mic, Mail, Share2, TrendingUp } from "lucide-react"
import { motion } from "framer-motion"
import ContactForm from "@/components/contact-form"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { GoBackButton } from "@/components/go-back-button"
import { RobotLoader } from "@/components/robot-loader"

const services = [
  {
    title: "AI for ChatBot",
    description: "Enhance customer engagement with intelligent, AI-driven chatbots",
    icon: MessageSquare,
    features: [
      "Natural language processing",
      "Multi-platform integration",
      "Personalized user interactions",
      "Continuous learning and improvement",
      "Analytics and performance tracking",
    ],
    learnMore:
      "AI-powered chatbots can revolutionize your customer service by providing instant, 24/7 support. They can handle multiple queries simultaneously, reduce response times, and free up your human agents for more complex tasks. By leveraging natural language processing, these chatbots can understand and respond to customer inquiries in a human-like manner, improving customer satisfaction and loyalty.",
  },
  {
    title: "AI for Avatar",
    description: "Create compelling visual representations with AI technology",
    icon: Video,
    features: [
      "Customizable digital avatars",
      "Realistic facial expressions",
      "Voice synchronization",
      "Multi-language support",
      "Integration with various platforms",
    ],
    learnMore:
      "AI-generated avatars can transform your brand's digital presence. They can serve as virtual brand ambassadors, provide personalized customer experiences, and enhance your marketing campaigns. These avatars can be used in virtual events, product demonstrations, and even in customer service interfaces, creating a unique and memorable interaction with your audience.",
  },
  {
    title: "AI for Voice Over",
    description: "Generate high-quality voice overs with AI technology",
    icon: Mic,
    features: [
      "Natural-sounding voices",
      "Multiple languages and accents",
      "Customizable tone and pace",
      "Quick turnaround times",
      "Cost-effective solution",
    ],
    learnMore:
      "AI-powered voice over technology can significantly reduce the time and cost associated with traditional voice recording. It allows for quick production of high-quality audio content in multiple languages, perfect for e-learning materials, explainer videos, or IVR systems. This technology can help you reach a global audience more effectively and create consistent brand messaging across various audio channels.",
  },
  {
    title: "AI for Email Marketing",
    description: "Optimize your email campaigns with AI-driven insights",
    icon: Mail,
    features: [
      "Personalized content recommendations",
      "Optimal send time prediction",
      "Subject line optimization",
      "Automated A/B testing",
      "Predictive analytics for campaign performance",
    ],
    learnMore:
      "AI can transform your email marketing strategy by analyzing vast amounts of data to personalize content, optimize send times, and predict campaign performance. This leads to higher open rates, click-through rates, and ultimately, conversions. AI can also help segment your audience more effectively, ensuring that each subscriber receives content that is most relevant to them.",
  },
  {
    title: "AI for Social Media Management & Advert",
    description: "Enhance your social media presence with AI-powered tools",
    icon: Share2,
    features: [
      "Content curation and generation",
      "Optimal posting schedule",
      "Sentiment analysis",
      "Automated ad optimization",
      "Influencer identification",
    ],
    learnMore:
      "AI can revolutionize your social media strategy by automating content curation, optimizing posting schedules, and providing deep insights into audience behavior. For advertising, AI can analyze vast amounts of data to target the right audience, optimize ad spend, and predict campaign performance. This results in more effective social media campaigns, better engagement rates, and improved ROI on your social media advertising efforts.",
  },
  {
    title: "AI for Sales/Revenue Growth",
    description: "Boost your sales and revenue with AI-driven strategies",
    icon: TrendingUp,
    features: [
      "Predictive lead scoring",
      "Sales forecasting",
      "Personalized product recommendations",
      "Churn prediction and prevention",
      "Dynamic pricing optimization",
    ],
    learnMore:
      "AI can significantly impact your sales and revenue growth by providing predictive insights and automating key processes. It can help identify the most promising leads, forecast sales with higher accuracy, and provide personalized product recommendations to customers. AI can also predict and prevent customer churn, and optimize pricing strategies in real-time. By leveraging AI, businesses can make data-driven decisions that lead to increased sales efficiency and revenue growth.",
  },
]

export default function ServicesPage() {
  const [selectedService, setSelectedService] = useState<string | null>(null)
  const [showThankYou, setShowThankYou] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleGetStarted = (service: string) => {
    setSelectedService(service)
    setShowThankYou(false)
  }

  const handleFormSubmit = async (formData: FormData) => {
    setIsLoading(true)
    const submission = {
      service: selectedService || "",
      name: formData.get("name") as string,
      email: formData.get("email") as string,
      whatsapp: formData.get("whatsapp") as string,
    }

    try {
      const response = await fetch("/api/submit-service", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(submission),
      })

      if (response.ok) {
        setShowThankYou(true)
      } else {
        throw new Error("Submission failed")
      }
    } catch (error) {
      console.error("Error submitting form:", error)
      alert("There was an error submitting your request. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen pt-24 pb-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <GoBackButton />
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Agency Services</h1>
          <p className="text-xl text-gray-600">
            Transform your business with our professional AI services. We offer cutting-edge solutions tailored to your
            specific needs.
          </p>
        </div>

        {isLoading && <RobotLoader />}

        {!selectedService && !isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                      <service.icon className="w-6 h-6 text-green-600" />
                    </div>
                    <CardTitle>{service.title}</CardTitle>
                    <CardDescription>{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <ul className="space-y-2">
                        {service.features.map((feature, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-green-600 rounded-full" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button onClick={() => handleGetStarted(service.title)}>Get Started</Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline">Learn More</Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[425px]">
                        <DialogHeader>
                          <DialogTitle>{service.title}</DialogTitle>
                          <DialogDescription>{service.learnMore}</DialogDescription>
                        </DialogHeader>
                      </DialogContent>
                    </Dialog>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {selectedService && !showThankYou && !isLoading && (
          <div className="max-w-md mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-center">Get Started with {selectedService}</h2>
            <ContactForm onSubmit={handleFormSubmit} submitButtonText="Submit Request" />
          </div>
        )}

        {showThankYou && !isLoading && (
          <div className="max-w-md mx-auto text-center">
            <h2 className="text-2xl font-bold mb-4">Thank You!</h2>
            <p className="text-lg text-gray-600 mb-8">
              We've received your request for {selectedService}. We'll get back to you shortly with more information.
            </p>
            <Button onClick={() => setSelectedService(null)}>Explore More Services</Button>
          </div>
        )}
      </div>
    </main>
  )
}


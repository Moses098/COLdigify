import Image from 'next/image'
import { motion } from 'framer-motion'

export default function AboutPage() {
  return (
    <main className="min-h-screen pt-24 pb-12 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.h1 
            className="text-5xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-blue-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            About COLdigify
          </motion.h1>
          
          <div className="space-y-16">
            {/* Hero Image */}
            <motion.div 
              className="relative h-[300px] sm:h-[400px] rounded-xl overflow-hidden shadow-2xl"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AI-in-Africa.jpg-fIhLniYfLgS47dKGtgcDHu8IZD3cmM.jpeg"
                alt="COLdigify AI Innovation"
                layout="fill"
                objectFit="cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <h2 className="text-2xl font-bold mb-2">Empowering Africa through AI</h2>
                <p>Leading the AI revolution in the heart of Africa</p>
              </div>
            </motion.div>

            {/* Mission & Vision */}
            <section className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <h2 className="text-3xl font-semibold mb-4 text-green-600">Our Mission</h2>
                <p className="text-lg text-gray-700 leading-relaxed">
                  At COLdigify, our mission is to bridge the gap between African talent and global AI opportunities. 
                  We're committed to empowering businesses and individuals across the continent with cutting-edge 
                  AI solutions and world-class training programs, fostering innovation and growth in the African tech ecosystem.
                </p>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
              >
                <h2 className="text-3xl font-semibold mb-4 text-blue-600">Our Vision</h2>
                <p className="text-lg text-gray-700 leading-relaxed">
                  To be the leading force in Africa's AI revolution, creating opportunities and fostering innovation 
                  that puts African talent at the forefront of global technological advancement. We envision a future 
                  where Africa is a key player in shaping the global AI landscape, driving economic growth and 
                  solving complex challenges through innovative AI solutions.
                </p>
              </motion.div>
            </section>

            {/* Company History */}
            <motion.section 
              className="space-y-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
            >
              <h2 className="text-3xl font-semibold mb-4 text-purple-600">Our Journey</h2>
              <p className="text-lg text-gray-700 leading-relaxed">
                Founded in 2018, COLdigify has grown from a small AI consultancy to become Africa's premier 
                AI agency and training institution. Our journey began with a vision to transform how African 
                businesses leverage artificial intelligence and to create opportunities for African talent in 
                the global AI landscape. Today, we stand at the forefront of AI innovation in Africa, continually 
                pushing boundaries and setting new standards in AI education and implementation.
              </p>
            </motion.section>

            {/* Values */}
            <section className="space-y-8">
              <h2 className="text-3xl font-semibold mb-6 text-center text-indigo-600">Our Values</h2>
              <div className="grid sm:grid-cols-2 gap-6">
                <motion.div 
                  className="p-6 bg-gradient-to-br from-green-50 to-blue-50 rounded-lg shadow-md"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <h3 className="font-semibold text-xl mb-2 text-green-600">Innovation</h3>
                  <p className="text-gray-700">
                    We constantly push the boundaries of what's possible with AI technology, fostering a culture of 
                    creativity and forward-thinking.
                  </p>
                </motion.div>
                <motion.div 
                  className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg shadow-md"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <h3 className="font-semibold text-xl mb-2 text-blue-600">Excellence</h3>
                  <p className="text-gray-700">
                    We maintain the highest standards in all our services and training programs, ensuring world-class 
                    quality in everything we do.
                  </p>
                </motion.div>
                <motion.div 
                  className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg shadow-md"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <h3 className="font-semibold text-xl mb-2 text-purple-600">Integrity</h3>
                  <p className="text-gray-700">
                    We operate with transparency and ethical consideration in all we do, building trust with our 
                    clients, students, and partners.
                  </p>
                </motion.div>
                <motion.div 
                  className="p-6 bg-gradient-to-br from-pink-50 to-orange-50 rounded-lg shadow-md"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <h3 className="font-semibold text-xl mb-2 text-pink-600">Impact</h3>
                  <p className="text-gray-700">
                    We measure our success by the positive change we create in Africa, focusing on solutions that 
                    drive meaningful progress and development.
                  </p>
                </motion.div>
              </div>
            </section>

            {/* Team */}
            <motion.section 
              className="space-y-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 1 }}
            >
              <h2 className="text-3xl font-semibold mb-4 text-center text-orange-600">Our Team</h2>
              <p className="text-lg text-gray-700 leading-relaxed text-center">
                Our team consists of over 50 AI experts, researchers, and industry professionals dedicated 
                to advancing AI adoption in Africa. We bring together diverse expertise from machine learning, 
                data science, software engineering, and business strategy to deliver comprehensive AI solutions 
                and training.
              </p>
            </motion.section>
          </div>
        </div>
      </div>
    </main>
  )
}


export default function TermsOfService() {
  return (
    <main className="min-h-screen pt-24 pb-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
        <div className="prose max-w-none">
          <p>Last updated: [Current Date]</p>
          <p>
            Please read these Terms of Service ("Terms", "Terms of Service") carefully before using the COLdigify website or any services provided by COLdigify ("us", "we", or "our").
          </p>
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing or using our Service, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access the Service.
          </p>
          <h2>2. Description of Service</h2>
          <p>
            COLdigify provides AI solutions and training services. We reserve the right to modify, suspend or discontinue, temporarily or permanently, the Service with or without notice.
          </p>
          <h2>3. User Accounts</h2>
          <p>
            When you create an account with us, you must provide information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.
          </p>
          <h2>4. Intellectual Property</h2>
          <p>
            The Service and its original content, features, and functionality are and will remain the exclusive property of COLdigify and its licensors. The Service is protected by copyright, trademark, and other laws.
          </p>
          <h2>5. Termination</h2>
          <p>
            We may terminate or suspend access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
          </p>
          <h2>6. Limitation of Liability</h2>
          <p>
            In no event shall COLdigify, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.
          </p>
          <h2>7. Changes</h2>
          <p>
            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. What constitutes a material change will be determined at our sole discretion.
          </p>
          <h2>8. Contact Us</h2>
          <p>
            If you have any questions about these Terms, please contact us at: [Contact Email]
          </p>
        </div>
      </div>
    </main>
  )
}


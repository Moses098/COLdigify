import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import ScrollHeader from "@/components/scroll-header"
import Footer from "@/components/footer"
import { ThemeProvider } from "@/components/theme-provider"
import { ModeToggle } from "@/components/mode-toggle"
import { AdminProvider } from "@/contexts/AdminContext"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "COLdigify - AI Agency",
  description: "Leading AI solutions for Africa and beyond",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${inter.className} min-h-screen flex flex-col`}>
        <AdminProvider>
          <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
            <ScrollHeader />
            <main className="flex-grow pt-20">
              <div className="fixed bottom-4 right-4 z-50">
                <ModeToggle />
              </div>
              {children}
            </main>
            <Footer />
          </ThemeProvider>
        </AdminProvider>
      </body>
    </html>
  )
}


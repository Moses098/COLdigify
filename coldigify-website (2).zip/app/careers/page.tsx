"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { ArrowRight, Code, BarChart, Megaphone, Shield, MessageSquare, Video, Brain } from "lucide-react"
import { motion } from "framer-motion"
import ContactForm from "@/components/contact-form"
import CareerRoadmap from "@/components/career-roadmap"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { GoBackButton } from "@/components/go-back-button"
import { RobotLoader } from "@/components/robot-loader"

const careers = [
  {
    title: "AI for Full Stack Developer",
    description: "Learn to integrate AI into web and mobile applications",
    icon: Code,
    skills: ["Web Development", "Mobile Development", "AI Integration", "API Development"],
    duration: "2 months",
    level: "Intermediate",
    learnMore:
      "Become a sought-after AI-powered Full Stack Developer. This course will equip you with the skills to build cutting-edge web and mobile applications infused with AI capabilities. You'll learn to create intelligent user interfaces, implement machine learning models, and develop AI-driven features that set your applications apart. With these skills, you can freelance for international clients, work remotely for tech companies worldwide, or even start your own AI-focused development agency, all while earning in dollars.",
  },
  {
    title: "AI for Data Analysis",
    description: "Master data analysis techniques using AI and machine learning",
    icon: BarChart,
    skills: ["Data Visualization", "Statistical Analysis", "Machine Learning", "Big Data"],
    duration: "2 months",
    level: "Intermediate",
    learnMore:
      "Transform raw data into valuable insights with AI-powered data analysis. This course will teach you how to leverage machine learning algorithms to uncover patterns, make predictions, and drive data-informed decisions. As a skilled AI Data Analyst, you can offer your services to global companies, work on international data science projects, or consult for businesses worldwide, all from the comfort of your home while earning in dollars.",
  },
  {
    title: "AI for Digital Marketing",
    description: "Leverage AI to enhance digital marketing strategies",
    icon: Megaphone,
    skills: ["Marketing Analytics", "AI-Driven Campaigns", "Personalization", "Predictive Marketing"],
    duration: "2 months",
    level: "Beginner to Intermediate",
    learnMore:
      "Revolutionize digital marketing with AI-powered strategies. Learn how to use AI for customer segmentation, personalized content creation, and predictive analytics. With these skills, you can offer high-value digital marketing services to clients globally, work with international brands on their AI-driven marketing campaigns, or even start your own AI marketing agency, all while working remotely and earning in dollars.",
  },
  {
    title: "AI for Cyber Security",
    description: "Implement AI-powered security solutions to protect digital assets",
    icon: Shield,
    skills: ["Threat Detection", "Anomaly Detection", "Security Automation", "Risk Assessment"],
    duration: "2 months",
    level: "Advanced",
    learnMore:
      "Become an AI Cybersecurity expert and protect businesses from evolving digital threats. This course will teach you how to implement AI-powered security solutions, automate threat detection, and enhance overall cybersecurity posture. With these in-demand skills, you can offer your services to companies worldwide, work remotely for international cybersecurity firms, or consult for businesses globally, all while earning in dollars from the comfort of your home.",
  },
  {
    title: "AI Automation for Chatbot",
    description: "Design and develop intelligent chatbots for various applications",
    icon: MessageSquare,
    skills: ["Natural Language Processing", "Conversational AI", "Integration", "User Experience"],
    duration: "2 months",
    level: "Intermediate",
    learnMore:
      "Master the art of creating intelligent, AI-powered chatbots. Learn to design conversational interfaces that can understand and respond to user queries naturally. With these skills, you can develop chatbots for businesses worldwide, offer your services to international companies looking to automate customer support, or even create your own chatbot products. This course opens up numerous opportunities to work remotely and earn in dollars.",
  },
  {
    title: "AI for Avatar/Content Creation & Voice Over",
    description: "Create AI-powered avatars, content, and voice overs",
    icon: Video,
    skills: ["Computer Vision", "Text-to-Speech", "Content Generation", "Video Synthesis"],
    duration: "2 months",
    level: "Intermediate to Advanced",
    learnMore:
      "Dive into the exciting world of AI-powered content creation. Learn to generate realistic avatars, create engaging content, and produce natural-sounding voice overs using AI. These cutting-edge skills will allow you to offer unique services to clients globally, work on international projects for media companies, or even start your own AI content creation studio. This course equips you with the tools to work from home while earning in dollars in the rapidly growing field of AI-generated media.",
  },
  {
    title: "AI for Machine Learning",
    description: "Deep dive into machine learning algorithms and applications",
    icon: Brain,
    skills: ["Supervised Learning", "Unsupervised Learning", "Deep Learning", "Model Deployment"],
    duration: "2 months",
    level: "Advanced",
    learnMore:
      "Become an expert in Machine Learning and unlock the power of AI. This course will take you through advanced ML algorithms, deep learning techniques, and real-world applications. With these high-demand skills, you can work on cutting-edge AI projects for companies around the globe, contribute to international research teams, or develop your own AI solutions. The knowledge gained from this course positions you perfectly for remote work opportunities that pay in dollars.",
  },
]

export default function CareersPage() {
  const [selectedCareer, setSelectedCareer] = useState<string | null>(null)
  const [showRoadmap, setShowRoadmap] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleApply = (career: string) => {
    setSelectedCareer(career)
    setShowRoadmap(false)
  }

  const handleFormSubmit = async (formData: FormData) => {
    setIsLoading(true)
    const submission = {
      career: selectedCareer || "",
      name: formData.get("name") as string,
      email: formData.get("email") as string,
      whatsapp: formData.get("whatsapp") as string,
    }

    try {
      const response = await fetch("/api/submit-career", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(submission),
      })

      if (response.ok) {
        setShowRoadmap(true)
      } else {
        throw new Error("Submission failed")
      }
    } catch (error) {
      console.error("Error submitting form:", error)
      alert("There was an error submitting your application. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleBackToList = () => {
    setSelectedCareer(null)
    setShowRoadmap(false)
  }

  const roadmapSteps = [
    { title: "Foundations", description: "Learn the basics of AI and programming fundamentals." },
    { title: "Core Concepts", description: "Deep dive into key AI concepts and methodologies." },
    { title: "Practical Applications", description: "Apply your knowledge to real-world projects." },
    { title: "Advanced Topics", description: "Explore cutting-edge AI techniques and technologies." },
    { title: "Final Project", description: "Demonstrate your skills with a comprehensive AI project." },
    {
      title: "Career Preparation",
      description: "Prepare for your AI career with interview practice and portfolio building.",
    },
  ]

  return (
    <main className="min-h-screen pt-24 pb-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <GoBackButton />
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Choose Your AI Career Path</h1>
          <p className="text-xl text-gray-600">
            Embark on a transformative journey in AI with our comprehensive training programs. Select the path that
            aligns with your passion and career goals.
          </p>
        </div>

        {isLoading && <RobotLoader />}

        {!selectedCareer && !isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {careers.map((career, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                      <career.icon className="w-6 h-6 text-green-600" />
                    </div>
                    <CardTitle>{career.title}</CardTitle>
                    <CardDescription>{career.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold mb-2">Key Skills:</h4>
                        <div className="flex flex-wrap gap-2">
                          {career.skills.map((skill, i) => (
                            <span key={i} className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>Duration: {career.duration}</span>
                        <span>Level: {career.level}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button className="group" onClick={() => handleApply(career.title)}>
                      Apply Now
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline">Learn More</Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[425px]">
                        <DialogHeader>
                          <DialogTitle>{career.title}</DialogTitle>
                          <DialogDescription>{career.learnMore}</DialogDescription>
                        </DialogHeader>
                      </DialogContent>
                    </Dialog>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {selectedCareer && !showRoadmap && !isLoading && (
          <div className="max-w-md mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-center">Apply for {selectedCareer}</h2>
            <ContactForm onSubmit={handleFormSubmit} submitButtonText="Submit Application" />
            <Button onClick={handleBackToList} className="mt-4 w-full">
              Back to Career List
            </Button>
          </div>
        )}

        {showRoadmap && !isLoading && (
          <div>
            <CareerRoadmap steps={roadmapSteps} />
            <Button onClick={handleBackToList} className="mt-8 mx-auto block">
              Back to Career List
            </Button>
          </div>
        )}
      </div>
    </main>
  )
}


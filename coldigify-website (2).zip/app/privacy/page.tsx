export default function PrivacyPolicy() {
  return (
    <main className="min-h-screen pt-24 pb-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
        <div className="prose max-w-none">
          <p>Last updated: [Current Date]</p>
          <p>
            COLdigify ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how your personal information is collected, used, and disclosed by COLdigify.
          </p>
          <h2>Information We Collect</h2>
          <p>
            We collect information you provide directly to us, such as when you create an account, subscribe to our newsletter, or contact us for support. This information may include your name, email address, phone number, and any other information you choose to provide.
          </p>
          <h2>How We Use Your Information</h2>
          <p>
            We use the information we collect to provide, maintain, and improve our services, to develop new ones, and to protect COLdigify and our users.
          </p>
          <h2>Sharing of Information</h2>
          <p>
            We may share your information with third-party vendors, consultants, and other service providers who need access to such information to carry out work on our behalf.
          </p>
          <h2>Data Retention</h2>
          <p>
            We will retain your information for as long as your account is active or as needed to provide you services, comply with our legal obligations, resolve disputes, and enforce our agreements.
          </p>
          <h2>Changes to This Privacy Policy</h2>
          <p>
            We may change this privacy policy from time to time. If we make changes, we will notify you by revising the date at the top of the policy.
          </p>
          <h2>Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at: [Contact Email]
          </p>
        </div>
      </div>
    </main>
  )
}


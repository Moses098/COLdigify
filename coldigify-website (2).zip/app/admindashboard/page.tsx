"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAdmin } from "@/contexts/AdminContext"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion, AnimatePresence } from "framer-motion"
import { Trash2, BarChart2, Users, Briefcase, Award, LogOut } from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { RobotLoader } from "@/components/robot-loader"

export default function AdminDashboard() {
  const router = useRouter()
  const {
    isLoggedIn,
    setIsLoggedIn,
    announcements,
    setAnnouncements,
    serviceSubmissions,
    careerSubmissions,
    deleteAnnouncement,
    visitorData,
    popularityData,
  } = useAdmin()

  const [password, setPassword] = useState("")
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [showResetCode, setShowResetCode] = useState(false)
  const [resetCode, setResetCode] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [announcement, setAnnouncement] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isDataLoading, setIsDataLoading] = useState(true)
  const [dataError, setDataError] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const correctPassword = "Cornel86394738"

  useEffect(() => {
    if (isLoggedIn) {
      setIsDataLoading(true)
      setError(null)
      const fetchData = async () => {
        try {
          // Simulate a delay to show loading state
          await new Promise((resolve) => setTimeout(resolve, 2000))
          setIsDataLoading(false)
        } catch (error) {
          console.error("Error fetching data:", error)
          setError("Failed to load dashboard data. Please try again later.")
          setIsDataLoading(false)
        }
      }
      fetchData()
    }
  }, [isLoggedIn])

  useEffect(() => {
    if (loginAttempts >= 5) {
      setShowResetCode(true)
    }
  }, [loginAttempts])

  const handleLogin = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    if (password === correctPassword) {
      setIsLoggedIn(true)
    } else {
      setLoginAttempts((prev) => prev + 1)
      alert("Incorrect password. Please try again.")
    }
    setIsLoading(false)
  }

  const handleResetPassword = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    if (resetCode === "grow") {
      if (newPassword) {
        alert("Password reset successful. Please login with your new password.")
        setShowResetCode(false)
        setLoginAttempts(0)
      } else {
        alert("Please enter a new password.")
      }
    } else {
      alert("Incorrect reset code. Please try again.")
    }
    setIsLoading(false)
  }

  const handleAddAnnouncement = async () => {
    if (announcement) {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setAnnouncements([
        ...announcements,
        { id: Date.now().toString(), text: announcement, createdAt: new Date().toISOString() },
      ])
      setAnnouncement("")
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    router.push("/")
  }

  const preparePopularityData = (data: { [key: string]: number }) => {
    return Object.entries(data)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-green-400 to-blue-500">
        <motion.div initial={{ opacity: 0, y: -50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-center">Admin Login</CardTitle>
            </CardHeader>
            <CardContent>
              {!showResetCode ? (
                <>
                  <Input
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="mb-4"
                  />
                  <Button
                    onClick={handleLogin}
                    className="w-full bg-gradient-to-r from-green-500 to-blue-600 text-white"
                    disabled={isLoading}
                  >
                    {isLoading ? "Logging in..." : "Login"}
                  </Button>
                </>
              ) : (
                <>
                  <Input
                    type="text"
                    placeholder="Enter reset code"
                    value={resetCode}
                    onChange={(e) => setResetCode(e.target.value)}
                    className="mb-4"
                  />
                  <Input
                    type="password"
                    placeholder="Enter new password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="mb-4"
                  />
                  <Button
                    onClick={handleResetPassword}
                    className="w-full bg-gradient-to-r from-green-500 to-blue-600 text-white"
                    disabled={isLoading}
                  >
                    {isLoading ? "Resetting..." : "Reset Password"}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    )
  }

  if (isDataLoading) {
    return <RobotLoader />
  }

  if (dataError) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl font-semibold text-red-500">{dataError}</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl font-semibold text-red-500">{error}</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen p-8 bg-gradient-to-r from-green-50 to-blue-50">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-7xl mx-auto"
      >
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-green-600">Admin Dashboard</h1>
          <Button onClick={handleLogout} variant="outline" className="flex items-center gap-2">
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-green-100 to-blue-100 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Submissions</CardTitle>
              <BarChart2 className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{visitorData.totalSubmissions}</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-purple-100 to-pink-100 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Agency Services Submissions</CardTitle>
              <Briefcase className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{visitorData.agencyServicesSubmissions}</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-yellow-100 to-orange-100 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Career Path Submissions</CardTitle>
              <Users className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{visitorData.careerPathSubmissions}</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-red-100 to-orange-100 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Most Popular Service/Career</CardTitle>
              <Award className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Object.entries({ ...popularityData.services, ...popularityData.careers }).sort(
                  (a, b) => b[1] - a[1],
                )[0]?.[0] || "N/A"}
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="w-full justify-center mb-8 bg-white shadow-md rounded-lg p-1">
            <TabsTrigger value="overview" className="data-[state=active]:bg-green-100">
              Overview
            </TabsTrigger>
            <TabsTrigger value="announcements" className="data-[state=active]:bg-blue-100">
              Announcements
            </TabsTrigger>
            <TabsTrigger value="services" className="data-[state=active]:bg-purple-100">
              Agency Services
            </TabsTrigger>
            <TabsTrigger value="careers" className="data-[state=active]:bg-yellow-100">
              Career Paths
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Card className="bg-white shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-green-600">Submission Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={[
                      { name: "Total", value: visitorData.totalSubmissions },
                      { name: "Services", value: visitorData.agencyServicesSubmissions },
                      { name: "Careers", value: visitorData.careerPathSubmissions },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="announcements">
            <Card className="bg-white shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-blue-600">Announcements</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Enter announcement"
                  value={announcement}
                  onChange={(e) => setAnnouncement(e.target.value)}
                  className="mb-4"
                />
                <Button
                  onClick={handleAddAnnouncement}
                  className="w-full mb-4 bg-gradient-to-r from-green-500 to-blue-600 text-white"
                  disabled={isLoading}
                >
                  {isLoading ? "Adding..." : "Add Announcement"}
                </Button>
                <AnimatePresence>
                  {announcements.map((a) => (
                    <motion.div
                      key={a.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="p-4 bg-white rounded-lg shadow-md flex justify-between items-center mb-4"
                    >
                      <div>
                        <p className="font-medium">{a.text}</p>
                        <p className="text-sm text-gray-500">{new Date(a.createdAt).toLocaleString()}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteAnnouncement(a.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="services">
            <Card className="bg-white shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-purple-600">Agency Services Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {serviceSubmissions.map((submission) => (
                    <motion.div
                      key={submission.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-white rounded-lg shadow-md"
                    >
                      <p>
                        <strong>Service:</strong> {submission.service}
                      </p>
                      <p>
                        <strong>Name:</strong> {submission.name}
                      </p>
                      <p>
                        <strong>Email:</strong> {submission.email}
                      </p>
                      <p>
                        <strong>WhatsApp:</strong> {submission.whatsapp}
                      </p>
                      <p className="text-sm text-gray-500">{new Date(submission.created_at).toLocaleString()}</p>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="careers">
            <Card className="bg-white shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-yellow-600">Career Path Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {careerSubmissions.map((submission) => (
                    <motion.div
                      key={submission.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-white rounded-lg shadow-md"
                    >
                      <p>
                        <strong>Career:</strong> {submission.career}
                      </p>
                      <p>
                        <strong>Name:</strong> {submission.name}
                      </p>
                      <p>
                        <strong>Email:</strong> {submission.email}
                      </p>
                      <p>
                        <strong>WhatsApp:</strong> {submission.whatsapp}
                      </p>
                      <p className="text-sm text-gray-500">{new Date(submission.created_at).toLocaleString()}</p>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  )
}


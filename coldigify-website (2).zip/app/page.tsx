import Hero from "@/components/hero"
import KeyBenefits from "@/components/key-benefits"
import SuccessMetrics from "@/components/success-metrics"
import QuickContact from "@/components/quick-contact"
import AgencyServices from "@/components/agency-services"
import TrainingSection from "@/components/training-section"
import VideoSection from "@/components/video-section"
import AboutUs from "@/components/about-us"
import GraduateCompanies from "@/components/graduate-companies"
import Testimonials from "@/components/testimonials"
import CertificateSection from "@/components/certificate-section"

export default function Home() {
  return (
    <>
      <Hero />
      <VideoSection
        videoSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/istockphoto-2096097569-640_adpp_is-rHsqDyXHcT5INtnhRMLfehTnzaYZPf.mp4"
        title="Revolutionizing African Business with AI"
      />
      <AgencyServices />
      <QuickContact />
      <TrainingSection />
      <CertificateSection />
      <GraduateCompanies />
      <Testimonials />
      <AboutUs />
      <KeyBenefits />
      <SuccessMetrics />
    </>
  )
}


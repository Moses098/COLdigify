import { motion } from 'framer-motion'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

export default function GetStartedPage() {
  return (
    <main className="min-h-screen pt-24 pb-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-8">Get Started with COLdigify</h1>
          <p className="text-xl text-gray-600 mb-12">
            Choose your path to success with COLdigify. Whether you're looking to transform your business 
            with AI or become an AI expert, we have the perfect solution for you.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Agency Services */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="p-8 rounded-xl bg-gradient-to-br from-orange-50 to-pink-50 border border-orange-100"
            >
              <h2 className="text-2xl font-bold mb-4">Hire Our Agency</h2>
              <p className="text-gray-600 mb-6">
                Transform your business with our cutting-edge AI solutions. Get expert consultation and 
                implementation services tailored to your needs.
              </p>
              <Link href="/services">
                <motion.button
                  className="px-6 py-3 bg-gradient-to-r from-orange-400 to-pink-500 text-white font-bold rounded-xl shadow-lg transform transition-all duration-300 ease-in-out hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-opacity-50"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="flex items-center">
                    Explore Services
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </span>
                </motion.button>
              </Link>
            </motion.div>

            {/* Training Programs */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="p-8 rounded-xl bg-gradient-to-br from-green-50 to-blue-50 border border-green-100"
            >
              <h2 className="text-2xl font-bold mb-4">Become a Student</h2>
              <p className="text-gray-600 mb-6">
                Start your journey to becoming an AI expert. Join our comprehensive training programs 
                and build a successful career in AI.
              </p>
              <Link href="/careers">
                <motion.button
                  className="px-6 py-3 bg-gradient-to-r from-green-400 to-blue-500 text-white font-bold rounded-xl shadow-lg transform transition-all duration-300 ease-in-out hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-opacity-50"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="flex items-center">
                    Start Learning
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </span>
                </motion.button>
              </Link>
            </motion.div>
          </div>
        </div>
      </div>
    </main>
  )
}


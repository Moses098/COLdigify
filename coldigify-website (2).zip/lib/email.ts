import { config } from './config';

export async function sendEmail(subject: string, text: string) {
  const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.sendgrid.apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      personalizations: [
        {
          to: [{ email: 'coldigify747@gmail.com' }],
        },
      ],
      from: { email: 'coldigify747@gmail.com' },
      subject: subject,
      content: [
        {
          type: 'text/plain',
          value: text,
        },
      ],
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to send email');
  }

  console.log('Email sent successfully');
}


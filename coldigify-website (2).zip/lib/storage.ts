type Submission = {
  id: string;
  createdAt: string;
  [key: string]: any;
};

class InMemoryStorage {
  private serviceSubmissions: Submission[] = [];
  private careerSubmissions: Submission[] = [];

  addServiceSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Submission {
    const newSubmission = {
      ...submission,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
    };
    this.serviceSubmissions.push(newSubmission);
    return newSubmission;
  }

  addCareerSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Submission {
    const newSubmission = {
      ...submission,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
    };
    this.careerSubmissions.push(newSubmission);
    return newSubmission;
  }

  getServiceSubmissions(): Submission[] {
    return this.serviceSubmissions;
  }

  getCareerSubmissions(): Submission[] {
    return this.careerSubmissions;
  }
}

const storage = new InMemoryStorage();
export default storage;


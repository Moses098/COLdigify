'use client'

import { motion } from 'framer-motion'

export const RobotLoader = () => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
      <motion.div
        className="w-40 h-40 bg-white rounded-full flex items-center justify-center"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 360],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <motion.div
          className="w-32 h-32 bg-gray-200 rounded-full flex flex-col items-center justify-center"
          animate={{
            scale: [1, 0.9, 1],
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <motion.div
            className="w-16 h-8 bg-blue-500 rounded-t-full"
            animate={{
              y: [-2, 2, -2],
            }}
            transition={{
              duration: 0.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <div className="w-20 h-10 bg-gray-300 rounded-b-full flex justify-around items-center">
            <motion.div
              className="w-3 h-3 bg-red-500 rounded-full"
              animate={{
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: 0.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
            <motion.div
              className="w-3 h-3 bg-green-500 rounded-full"
              animate={{
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: 0.5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.25,
              }}
            />
          </div>
        </motion.div>
      </motion.div>
    </div>
  )
}


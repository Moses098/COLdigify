import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Brain, Code, BarChart, Network } from 'lucide-react'

export default function Services() {
  const services = [
    {
      title: 'AI Consulting',
      description: 'Strategic guidance on implementing AI solutions for your business',
      icon: Brain
    },
    {
      title: 'Custom AI Development',
      description: 'Tailored AI solutions designed for your specific needs',
      icon: Code
    },
    {
      title: 'Data Analytics',
      description: 'Transform your data into actionable insights',
      icon: BarChart
    },
    {
      title: 'AI Integration',
      description: 'Seamlessly integrate AI into your existing systems',
      icon: Network
    }
  ]

  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
          <p className="text-xl text-gray-600">Comprehensive AI solutions for modern businesses</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="transition-all hover:shadow-lg">
              <CardHeader>
                <div className="mb-4 w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
                  <service.icon className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>{service.title}</CardTitle>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}


import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import VideoSection from './video-section'

const testimonials = [
  {
    name: 'John Doe',
    company: 'TechCorp',
    quote: 'COLDIGIFY has transformed our business with their innovative AI solutions.',
  },
  {
    name: 'Jane Smith',
    company: 'AI Innovations',
    quote: 'The AI professionals we hired from COLDIGIFY have significantly accelerated our product development.',
  },
  {
    name: 'Michael Johnson',
    company: 'DataDrive',
    quote: 'Working with COLDIGIFY has given us a competitive edge in the market.',
  },
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Client Testimonials</h2>
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2 space-y-4">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="bg-white">
                  <CardContent className="p-4">
                    <p className="text-sm text-gray-600 italic mb-3">"{testimonial.quote}"</p>
                    <div className="text-right">
                      <h3 className="font-semibold text-sm">{testimonial.name}</h3>
                      <p className="text-xs text-gray-500">{testimonial.company}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="md:w-1/2">
              <VideoSection 
                videoSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/istockphoto-1987136344-640_adpp_is-Mry13HXAVqBMVSSbZpy4EQZqRFR7GR.mp4"
                title=""
              />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}


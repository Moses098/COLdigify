import { motion } from 'framer-motion'
import VideoSection from './video-section'

export default function GraduateCompanies() {
  return (
    <section id="graduate-companies" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-8 text-center text-foreground">Where Our Graduates Work</h2>
          <div className="max-w-3xl mx-auto text-center mb-12">
            <p className="text-lg text-muted-foreground">
              Our graduates are making significant impacts in some of Africa's largest and most innovative companies. 
              From financial institutions to telecommunications giants, our alumni are driving AI adoption and 
              innovation across the continent. Their success stories are a testament to the quality of our training 
              programs and the growing demand for AI expertise in Africa's rapidly evolving business landscape.
            </p>
          </div>
          
          <VideoSection 
            videoSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/istockphoto-584315754-640_adpp_is-tMJp1YZtxPXmSzyY4sOluzh9IWR5LN.mp4"
            title=""
          />
          
        </motion.div>
      </div>
    </section>
  )
}


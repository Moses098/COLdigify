import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { CheckCircle } from 'lucide-react'
import VideoSection from './video-section'

export default function AboutUs() {
  const achievements = [
    "Founded in 2018",
    "Team of 50+ AI experts",
    "Partnerships with leading tech companies",
    "Committed to ethical AI development"
  ]

  return (
    <section id="about" className="py-24 bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-900 dark:to-blue-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row gap-12 items-center"
        >
          <div className="md:w-1/2">
            <h2 className="text-4xl font-bold mb-6 bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">About Us</h2>
            <p className="text-lg text-muted-foreground mb-6">
              COLdigify is at the forefront of AI innovation in Africa. We're committed to empowering businesses 
              and individuals across the continent with cutting-edge AI solutions and world-class training programs.
            </p>
            <p className="text-lg text-muted-foreground mb-6">
              Our mission is to bridge the gap between African talent and global AI opportunities, fostering 
              a new generation of tech leaders who will shape the future of AI in Africa and beyond.
            </p>
            <Card className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Our Achievements</h3>
                <ul className="space-y-2">
                  {achievements.map((achievement, index) => (
                    <motion.li 
                      key={index}
                      className="flex items-center gap-2"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <CheckCircle className="text-green-500 h-5 w-5" />
                      <span>{achievement}</span>
                    </motion.li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
          <div className="md:w-1/2 relative rounded-xl overflow-hidden shadow-xl">
            <VideoSection 
              videoSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/istockphoto-1345911760-640_adpp_is-MRUDRu1FfEFYTWRmxddx7snOmPYKvT.mp4"
              title=""
            />
            <div className="absolute bottom-4 left-4 right-4 text-white">
              <h3 className="text-2xl font-bold mb-2">Shaping Africa's AI Future</h3>
              <p className="text-sm">Join us in our mission to revolutionize the African tech landscape</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}


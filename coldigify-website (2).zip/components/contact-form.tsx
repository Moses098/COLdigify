"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const africanCountryCodes = [
  { code: "+234", country: "Nigeria" },
  { code: "+27", country: "South Africa" },
  { code: "+254", country: "Kenya" },
  { code: "+20", country: "Egypt" },
  { code: "+233", country: "Ghana" },
]

interface ContactFormProps {
  onSubmit: (data: FormData) => void
  submitButtonText: string
}

export default function ContactForm({ onSubmit, submitButtonText }: ContactFormProps) {
  const [countryCode, setCountryCode] = useState(africanCountryCodes[0].code)

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    formData.set("whatsapp", `${countryCode}${formData.get("whatsapp")}`)
    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Full Name</Label>
        <Input id="name" name="name" required />
      </div>
      <div>
        <Label htmlFor="whatsapp">WhatsApp Number</Label>
        <div className="flex">
          <Select value={countryCode} onValueChange={setCountryCode}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Country Code" />
            </SelectTrigger>
            <SelectContent>
              {africanCountryCodes.map((country) => (
                <SelectItem key={country.code} value={country.code}>
                  {country.country} ({country.code})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input id="whatsapp" name="whatsapp" type="tel" className="flex-1 ml-2" required />
        </div>
      </div>
      <div>
        <Label htmlFor="email">Email Address</Label>
        <Input id="email" name="email" type="email" required />
      </div>
      <Button type="submit" className="w-full">
        {submitButtonText}
      </Button>
    </form>
  )
}


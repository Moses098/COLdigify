import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { useAdmin } from '@/contexts/AdminContext'

export default function Hero() {
  const { announcements } = useAdmin()
  const latestAnnouncement = announcements[announcements.length - 1]

  return (
    <section className="relative min-h-[calc(100vh-5rem)] md:min-h-screen flex items-center overflow-hidden pt-20 pb-12 md:pb-0">
      <div 
        className="absolute inset-0 z-0 bg-gradient-to-br from-green-100 to-blue-100 dark:from-green-900 dark:to-blue-900"
      />
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="max-w-4xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="text-2xl md:text-3xl font-bold text-green-600 dark:text-green-400 mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            <motion.span
              className="inline-block bg-gradient-to-r from-green-400 to-blue-500 text-white px-6 py-3 rounded-full text-lg md:text-xl font-bold shadow-lg transform -rotate-2 hover:rotate-0 transition-all duration-300"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              #1 AI AGENCY & TRAINING INSTITUTE IN AFRICA
            </motion.span>
          </motion.div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6 bg-gradient-to-r from-green-600 to-blue-600 dark:from-green-400 dark:to-blue-400 bg-clip-text text-transparent">
            Transforming Africa Through AI Innovation
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-12">
            Empowering businesses with cutting-edge artificial intelligence solutions. 
            We bridge the gap between technology and African innovation.
          </p>
          {latestAnnouncement && (
            <motion.div
              className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-8 rounded-r-lg shadow-md"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              <p className="font-bold">Latest Announcement:</p>
              <p>{latestAnnouncement.text}</p>
            </motion.div>
          )}
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link href="/services">
              <Button size="lg" className="bg-gradient-to-r from-green-500 to-blue-600 text-white">
                Explore Our Services
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/careers">
              <Button size="lg" variant="outline" className="border-green-500 text-green-600 dark:border-green-400 dark:text-green-400">
                Start Your AI Career
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>

      <motion.div 
        className="absolute right-0 bottom-0 w-64 h-64 bg-green-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 dark:opacity-30"
        animate={{
          scale: [1, 2, 2, 1, 1],
          rotate: [0, 0, 270, 270, 0],
          borderRadius: ["20%", "20%", "50%", "50%", "20%"],
        }}
        transition={{
          duration: 20,
          ease: "easeInOut",
          times: [0, 0.2, 0.5, 0.8, 1],
          repeat: Infinity,
          repeatType: "reverse"
        }}
      />
      <motion.div 
        className="absolute right-20 bottom-20 w-48 h-48 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 dark:opacity-30"
        animate={{
          scale: [1.5, 1, 2, 1.5, 1.5],
          rotate: [0, 270, 0, 270, 0],
          borderRadius: ["50%", "20%", "50%", "20%", "50%"],
        }}
        transition={{
          duration: 25,
          ease: "easeInOut",
          times: [0, 0.2, 0.5, 0.8, 1],
          repeat: Infinity,
          repeatType: "reverse"
        }}
      />
    </section>
  )
}


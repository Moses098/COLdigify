import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'

export default function QuickContact() {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4 max-w-md">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold mb-2">Get Started Today</h3>
          <p className="text-gray-600">Reach out to us for a free consultation</p>
        </div>
        <form className="space-y-4">
          <div>
            <Input type="text" placeholder="Your Name" />
          </div>
          <div>
            <Input type="email" placeholder="Your Email" />
          </div>
          <div>
            <Textarea placeholder="How can we help you?" className="min-h-[100px]" />
          </div>
          <Button className="w-full">Send Message</Button>
        </form>
      </div>
    </section>
  )
}


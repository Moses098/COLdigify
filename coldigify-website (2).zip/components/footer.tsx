import Link from 'next/link'
import Image from 'next/image'
import { Facebook, Linkedin, Instagram, Mail, Phone, MapPin, Youtube, TwitterIcon as TikTok } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Footer() {
  return (
    <footer className="bg-white border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FB_IMG_1735199664361.jpg-j0jJ53VAcv1g69NHDP2Z5v4zSSY0fp.jpeg"
              alt="COLdigify Logo"
              width={150}
              height={50}
              className="h-12 w-auto"
            />
            <p className="text-muted-foreground mt-4">
              Empowering African businesses with cutting-edge AI solutions and training.
            </p>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="font-semibold text-lg mb-4 text-foreground">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-muted-foreground">
                <Mail className="h-5 w-5" />
                <a href="mailto:cokpiaifoh@gmail.com" className="hover:text-foreground transition-colors">cokpiaifoh@gmail.com</a>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-5 w-5" />
                <div>
                  <a href="tel:+2348144274752" className="hover:text-foreground transition-colors">+234 814 427 4752</a><br />
                  <a href="tel:+2347030818711" className="hover:text-foreground transition-colors">+234 703 081 8711</a>
                </div>
              </li>
              <li className="flex items-start gap-2 text-muted-foreground">
                <MapPin className="h-5 w-5 mt-1" />
                <address className="not-italic">
                  Lekki,<br />
                  Lagos, Nigeria
                </address>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4 text-foreground">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/services" className="text-muted-foreground hover:text-foreground transition-colors">
                  Our Services
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-muted-foreground hover:text-foreground transition-colors">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter Signup */}
          <div>
            <h3 className="font-semibold text-lg mb-4 text-foreground">Stay Updated</h3>
            <p className="text-muted-foreground mb-4">Subscribe to our newsletter for the latest AI insights and updates.</p>
            <form className="space-y-2">
              <input
                type="email"
                placeholder="Your email address"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <Button type="submit" className="w-full">Subscribe</Button>
            </form>
          </div>
        </div>

        {/* Social Media */}
        <div className="mt-8 flex justify-center space-x-6">
          <a 
            href="https://www.facebook.com/coldigify1?mibextid=ZbWKwL" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <Facebook className="h-6 w-6" />
          </a>
          <a 
            href="https://www.instagram.com/coldigify?igsh=MWVuenVmYnVyOWo4aA==" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <Instagram className="h-6 w-6" />
          </a>
          <a 
            href="https://www.linkedin.com/company/coldigify/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <Linkedin className="h-6 w-6" />
          </a>
          <a 
            href="https://youtube.com/@coldigify_01?si=u26w7g888-vMnFxC" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <Youtube className="h-6 w-6" />
          </a>
          <a 
            href="https://www.tiktok.com/@coldigify?_t=ZM-8t5Q6vF3XPy&_r=1" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <TikTok className="h-6 w-6" />
          </a>
        </div>

        {/* Bottom Bar */}
        <div className="border-t mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © 2018 COLdigify. All rights reserved.
            </p>
            <div className="flex gap-6">
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}


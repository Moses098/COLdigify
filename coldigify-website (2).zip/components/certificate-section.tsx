import { motion } from 'framer-motion'
import VideoSection from './video-section'

export default function CertificateSection() {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-6 text-center text-foreground">Earn Your AI Certification</h2>
          <p className="text-xl text-muted-foreground mb-12 text-center max-w-3xl mx-auto">
            Our comprehensive AI certification program validates your expertise and opens doors to exciting career opportunities in the rapidly growing field of artificial intelligence.
          </p>
          <VideoSection 
            videoSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/istockphoto-1214209224-640_adpp_is-o40w4QcLkw6HipQnGlDH5irUdxXDAI.mp4"
            title=""
          />
        </motion.div>
      </div>
    </section>
  )
}


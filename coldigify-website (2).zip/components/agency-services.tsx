import Link from 'next/link'
import { motion } from 'framer-motion'

export default function AgencyServices() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">AI AGENCY SERVICES</h2>
          <p className="text-xl text-gray-600 mb-8">
            Empowering African businesses with cutting-edge AI solutions to compete in the global market. 
            From optimizing supply chains to enhancing customer experiences, we provide comprehensive 
            AI strategies tailored for local needs and scalable growth.
          </p>
          <Link href="/services">
            <motion.button
              className="px-8 py-4 bg-gradient-to-r from-orange-400 to-pink-500 text-white font-bold rounded-xl shadow-lg transform transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-opacity-50"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="relative inline-block">
                Hire our Agency
                <motion.span
                  className="absolute bottom-0 left-0 w-full h-1 bg-white rounded"
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 0.3 }}
                />
              </span>
            </motion.button>
          </Link>
        </div>
      </div>
    </section>
  )
}


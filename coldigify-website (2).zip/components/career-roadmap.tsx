import { motion } from 'framer-motion'
import { CheckCircle } from 'lucide-react'

interface RoadmapStep {
  title: string;
  description: string;
}

interface CareerRoadmapProps {
  steps: RoadmapStep[];
}

export default function CareerRoadmap({ steps }: CareerRoadmapProps) {
  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">Your Learning Roadmap</h2>
      <div className="space-y-8">
        {steps.map((step, index) => (
          <motion.div
            key={index}
            className="flex items-start"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <div className="flex-shrink-0 mr-4">
              <CheckCircle className="w-6 h-6 text-green-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}


import { motion } from 'framer-motion'

interface VideoSectionProps {
  videoSrc: string;
  title: string;
  overlay?: boolean;
}

export default function VideoSection({ videoSrc, title, overlay = false }: VideoSectionProps) {
  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          {title && <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">{title}</h2>}
          <div className="relative aspect-video rounded-[2rem] overflow-hidden shadow-xl">
            <video 
              src={videoSrc} 
              className="w-full h-full object-cover"
              autoPlay 
              loop 
              muted 
              playsInline
            />
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent opacity-30" style={{ height: '20%', bottom: 0 }}></div>
              <div className="absolute inset-0 bg-gradient-to-b from-background to-transparent opacity-30" style={{ height: '20%', top: 0 }}></div>
              <div className="absolute inset-0 bg-gradient-to-r from-background to-transparent opacity-30" style={{ width: '20%', left: 0 }}></div>
              <div className="absolute inset-0 bg-gradient-to-l from-background to-transparent opacity-30" style={{ width: '20%', right: 0 }}></div>
            </div>
            {overlay && (
              <div className="absolute inset-0 bg-white bg-opacity-30"></div>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  )
}


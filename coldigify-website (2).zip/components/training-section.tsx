import { Card, CardContent } from '@/components/ui/card'
import { GraduationCap, Users, Trophy, Target } from 'lucide-react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import VideoSection from './video-section'

export default function TrainingSection() {
  const features = [
    {
      icon: GraduationCap,
      title: 'Expert-Led Training',
      description: 'Learn from industry professionals with real-world experience'
    },
    {
      icon: Users,
      title: 'Community Support',
      description: 'Join a community of African AI professionals and learners'
    },
    {
      icon: Trophy,
      title: 'Certification',
      description: 'Earn recognized certifications in AI specializations'
    },
    {
      icon: Target,
      title: 'Career Placement',
      description: 'Get connected with top companies hiring AI talent'
    }
  ]

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-6 text-foreground">We Are Training Africa's Next Generation of AI Experts</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join our comprehensive training program and become part of Africa's growing AI workforce.
              We provide the skills, tools, and support you need to succeed in the AI industry.
            </p>
            <Link href="/careers">
              <motion.button
                className="px-8 py-4 bg-gradient-to-r from-green-400 to-blue-500 text-white font-bold rounded-xl shadow-lg transform transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-opacity-50"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <span className="relative inline-block">
                  Become a Freelancer
                  <motion.span
                    className="absolute bottom-0 left-0 w-full h-1 bg-white rounded"
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                </span>
              </motion.button>
            </Link>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <feature.icon className="h-8 w-8 text-green-600 mb-4" />
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
        <div className="mt-16">
          <VideoSection 
            videoSrc="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/istockphoto-1850500154-640_adpp_is-1hjqvA2cJfWiocxl90ZHCXuwgKN0Sq.mp4"
            title=""
            overlay={true}
          />
        </div>
      </div>
    </section>
  )
}


"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type Submission = {
  id: number
  service?: string
  career?: string
  name: string
  email: string
  whatsapp: string
  created_at: string
}

type VisitorData = {
  totalSubmissions: number
  agencyServicesSubmissions: number
  careerPathSubmissions: number
}

type PopularityData = {
  services: { [key: string]: number }
  careers: { [key: string]: number }
}

type Announcement = {
  id: string
  title: string
  content: string
}

type AdminContextType = {
  isLoggedIn: boolean
  setIsLoggedIn: (value: boolean) => void
  announcements: Announcement[]
  setAnnouncements: (announcements: Announcement[]) => void
  serviceSubmissions: Submission[]
  setServiceSubmissions: (submissions: Submission[]) => void
  careerSubmissions: Submission[]
  setCareerSubmissions: (submissions: Submission[]) => void
  deleteAnnouncement: (id: string) => void
  visitorData: VisitorData
  setVisitorData: (data: VisitorData) => void
  popularityData: PopularityData
  setPopularityData: (data: PopularityData) => void
}

const AdminContext = createContext<AdminContextType | undefined>(undefined)

export const useAdmin = () => {
  const context = useContext(AdminContext)
  if (context === undefined) {
    throw new Error("useAdmin must be used within an AdminProvider")
  }
  return context
}

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [serviceSubmissions, setServiceSubmissions] = useState<Submission[]>([])
  const [careerSubmissions, setCareerSubmissions] = useState<Submission[]>([])
  const [visitorData, setVisitorData] = useState<VisitorData>({
    totalSubmissions: 0,
    agencyServicesSubmissions: 0,
    careerPathSubmissions: 0,
  })
  const [popularityData, setPopularityData] = useState<PopularityData>({
    services: {},
    careers: {},
  })

  useEffect(() => {
    if (isLoggedIn) {
      const fetchData = async () => {
        try {
          const [serviceRes, careerRes, visitorRes, popularityRes] = await Promise.all([
            fetch("/api/get-service-submissions"),
            fetch("/api/get-career-submissions"),
            fetch("/api/get-visitor-data"),
            fetch("/api/get-popularity-data"),
          ])

          const responses = [
            { name: "service", res: serviceRes },
            { name: "career", res: careerRes },
            { name: "visitor", res: visitorRes },
            { name: "popularity", res: popularityRes },
          ]

          for (const { name, res } of responses) {
            if (!res.ok) {
              throw new Error(`Failed to fetch ${name} data: ${res.statusText}`)
            }
          }

          const [serviceData, careerData, visitorData, popularityData] = await Promise.all([
            serviceRes.json(),
            careerRes.json(),
            visitorRes.json(),
            popularityRes.json(),
          ])

          setServiceSubmissions(serviceData)
          setCareerSubmissions(careerData)
          setVisitorData(visitorData)
          setPopularityData(popularityData)
        } catch (error) {
          console.error("Error fetching data:", error)
          // You might want to set some error state here to display in the UI
          setServiceSubmissions([])
          setCareerSubmissions([])
          setVisitorData({
            totalSubmissions: 0,
            agencyServicesSubmissions: 0,
            careerPathSubmissions: 0,
          })
          setPopularityData({ services: {}, careers: {} })
        }
      }

      fetchData()
    }
  }, [isLoggedIn])

  const deleteAnnouncement = (id: string) => {
    setAnnouncements((prevAnnouncements) => prevAnnouncements.filter((announcement) => announcement.id !== id))
  }

  return (
    <AdminContext.Provider
      value={{
        isLoggedIn,
        setIsLoggedIn,
        announcements,
        setAnnouncements,
        serviceSubmissions,
        setServiceSubmissions,
        careerSubmissions,
        setCareerSubmissions,
        deleteAnnouncement,
        visitorData,
        setVisitorData,
        popularityData,
        setPopularityData,
      }}
    >
      {children}
    </AdminContext.Provider>
  )
}

